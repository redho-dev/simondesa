<?php 
if($status_anggaran == 'anggaran_murni'){
    $anggaran = "anggaran_murni";
}elseif($status_anggaran == 'anggaran_perubahan'){
    $anggaran = "anggaran_perubahan";
}

?>
<p class="alert alert-info" style="font-size: 1rem">Form Input/Update Data Realisasi Pengadaan Aset Tetap Kantor TA
    {{
    $tahun }}</p>

<div class="row">
    <div class="col-md-12">
        @foreach($dapemb as $dp)
        @if(preg_match("/aset tetap/i",$dp->kegiatan->kegiatan))
        <table class="table table-bordered">
            <thead class="mt-2">
                <tr class="bg-info">
                    <th class="text-center" width="5%" style="vertical-align: middle">No</th>
                    <th width="20%">Nama Kegiatan</th>
                    <th class="text-center" width="10%" style="vertical-align: middle">Jumlah Anggaran (Rp)</th>
                    <th class="text-center" width="10%" style="vertical-align: middle">RAB</th>
                    <th class="text-center" width="55%" style="vertical-align: middle">Foto Barang <br>(jumlah foto
                        barang harus sesuai dengan jenis dan jumlah unit dalam RAB)</th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>{{ $dp->kegiatan->kegiatan}}</td>
                    <td class="text-center angka">{{ $dp->$anggaran
                        }}</td>
                    <td class="text-center">
                        <?php $data = $dp->pengadaan_aset->where('nama_data', 'rab')->first(); ?>
                        @if($data && $data->file_data)
                        <a href="{{ asset('storage/'.$data->file_data) }}" target="_blank"><img
                                src="{{  asset('img/logo-pdf.jpg') }}" width="50px" height="60px"></a>
                        @else
                        <p class="text-danger">kosong</p>
                        @endif
                    </td>
                    <td class="text-center d-flex flex-wrap justify-content-center">
                        <?php $data = $dp->pengadaan_aset->where('nama_data', 'foto_barang'); ?>
                        @if($data->count())
                        @foreach($data as $dt)
                        @if($dt && $dt->file_data)
                        <div class="d-flex flex-column">
                            <a href="{{ asset('storage/'.$dt->file_data) }}" target="_blank">
                                <img src="{{ asset('storage/'.$dt->file_data)  }}" width="100px" height="100px"
                                    class="mr-4">
                            </a>
                            <form action="/adminDesa/hapusFotoBarang" method="post">
                                @csrf
                                <input type="hidden" name="id" value="{{ $dt->id }}">
                                <button type="submit" class="btn btn-sm btn-danger my-2"><i
                                        class="fa fa-trash"></i></button>
                            </form>
                        </div>
                        @else
                        <p class="text-danger">kosong</p>
                        @endif
                        @endforeach
                        @else
                        <p class="text-danger">kosong</p>
                        @endif

                    </td>

                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="text-center">
                        <?php $data = $dp->pengadaan_aset->where('nama_data', 'rab')->first(); ?>
                        @if($data && $data->file_data)
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#rab">
                            Ganti RAB
                        </button>
                        @else
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#rab">
                            Upoad RAB
                        </button>
                        @endif
                    </td>
                    <td class="text-center">

                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                            data-target="#fotoBarang">
                            + Foto Barang
                        </button>
                    </td>
                    <!-- Modal -->
                    <div class="modal fade" id="fotoBarang" data-backdrop="static" data-keyboard="false" tabindex="-1"
                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered ">
                            <div class="modal-content">
                                <div class="modal-header bg-info">
                                    <h5 class="modal-title text-light" id="staticBackdropLabel">Form Upload Foto Barang
                                        (Belanja Aset kantor)</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="/adminDesa/tambahFotoBarang" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="asal_id" value="{{ $infos->asal_id }}">
                                    <input type="hidden" name="tahun" value="{{ $tahun }}">
                                    <input type="hidden" name="apbdes_kegiatan_id" value="{{ $dp->id }}">
                                    <input type="hidden" name="jumlah_anggaran" value="{{ $dp->$anggaran }}">
                                    <div class="modal-body">

                                        <div class="form-group">
                                            <label for="kegiatan">Nama Kegiatan</label>
                                            <input type="text" class="form-control"
                                                value="{{ $dp->kegiatan->kegiatan }}" style="font-size: .8rem" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="kegiatan">Foto Barang</label>
                                            <div class="custom-file">
                                                <input type="hidden" name="nama_data" value="foto_barang">
                                                <input type="file" name="foto_barang"
                                                    class="custom-file-input foto_barang" id="customFile">
                                                <label class="custom-file-label label_foto_barang" for="customFile"
                                                    style="font-size: .7rem">Choose
                                                    file
                                                    Image Max (1
                                                    MB)</label>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btn-sm"
                                            data-dismiss="modal">Close</button>

                                        <button type="submit" class="btn btn-primary btn-sm">KIRIM</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="rab" data-backdrop="static" data-keyboard="false" tabindex="-1"
                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header bg-info">
                                    <h5 class="modal-title text-light" id="staticBackdropLabel">Form Upload Rincian
                                        Anggaran Biaya (RAB) Kegiatan Pengadaan Aset Kantor</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="/adminDesa/tambahRabAset" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="asal_id" value="{{ $infos->asal_id }}">
                                    <input type="hidden" name="tahun" value="{{ $tahun }}">
                                    <input type="hidden" name="apbdes_kegiatan_id" value="{{ $dp->id }}">
                                    <input type="hidden" name="jumlah_anggaran" value="{{ $dp->$anggaran }}">
                                    <div class="modal-body">

                                        <div class="form-group">
                                            <label for="kegiatan">Nama Kegiatan</label>
                                            <input type="text" class="form-control"
                                                value="{{ $dp->kegiatan->kegiatan }}" style="font-size: .8rem" readonly>
                                        </div>

                                        <div class="form-group">
                                            <label for="kegiatan">Upload file RAB </label>
                                            <div class="custom-file">
                                                <input type="hidden" name="nama_data" value="rab">
                                                <input type="file" name="rab" class="custom-file-input rab"
                                                    id="customFile rab" required>
                                                <label class="custom-file-label label_rab" for="customFile"
                                                    style="font-size: .75rem">Choose
                                                    file
                                                    PDF (1
                                                    MB)</label>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btn-sm"
                                            data-dismiss="modal">Close</button>
                                        <?php $data = $dp->pengadaan_aset->where('nama_data', 'rab')->first(); ?>
                                        @if($data && $data->file_data)
                                        <input type="hidden" name="old" value="{{ $data->file_data }}">
                                        <button type="submit" name="update" class="btn btn-primary btn-sm">UPDATE
                                            DATA</button>
                                        @else
                                        <button type="submit" name="kirim" value="1"
                                            class="btn btn-primary btn-sm">KIRIM
                                            DATA</button>
                                        @endif
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </tr>
            </tbody>
        </table>
        @endif
        @endforeach




    </div>
</div>