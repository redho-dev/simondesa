<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        {{-- <h3>General</h3> --}}

        <ul class="nav side-menu">


            <li><a><i class="fa fa-home"></i> HOME <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="/adminIrbanwil">Rekap Data Obrik</a></li>
                    <li><a href="/rekapPenilaian">Rekap Penilaian</a></li>
                    <li><a href="/adminIrbanwil/penilaianAkun">Penilaian
                            Akuntabilitas</a></li>
                    <li><a href="/adminIrbanwil/penilaianAkun/cek">Rekap Catatan & Rekomendasi</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-edit"></i> Penilaian Akuntabilitas <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="/adminIrbanwil/pilihObrik">Cek Rekap Data & Nilai </a></li>
                    <li><a>Pemerintahan Desa<span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li class="sub_menu"><a href="/adminIrbanwil/datum">Data Umum/Monografi</a>
                            </li>
                            <li><a href="/adminIrbanwil/kewilayahan">Kewilayahan</a>
                            </li>
                            <li><a href="/adminIrbanwil/kelembagaan">Kelembagaan</a>
                            </li>
                            <li><a href="/adminIrbanwil/dokren">Dokumen Perencanaan</a>
                            </li>
                            <li><a href="/adminIrbanwil/adum">Administrasi Umum</a>
                            </li>
                            <li><a href="/adminIrbanwil/pelaporan">Pelaporan</a>
                            </li>
                        </ul>
                    </li>
                    <li><a>Penataan Keuangan <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li class="sub_menu"><a href="/adminIrbanwil/cekApbdes_m">Cek APBDes Murni</a>
                            </li>
                            <li><a href="/adminIrbanwil/cekApbdes_p">Cek APBDes Perubahan</a>
                            </li>
                            <li><a href="/adminIrbanwil/pendapatan">Penataan Pendapatan</a>
                            </li>
                            <li><a href="/adminIrbanwil/belanja">Penataan Belanja</a>
                            </li>
                            <li><a href="/adminIrbanwil/pembiayaan">Penataan Pembiayaan</a>
                            </li>
                            <li><a href="/adminIrbanwil/pajak">Kepatuhan Pajak</a>
                            </li>

                        </ul>
                    </li>
                    <li><a>Pengadaan Barjas <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li class="sub_menu"><a href="/adminIrbanwil/pembFisik">Pembangunan Fisik</a>
                            </li>
                            <li><a href="/adminIrbanwil/pengAset">Belanja Aset Tetap</a>
                            </li>
                            <li><a href="/adminIrbanwil/penIndset">Penilaian Indikator</a>
                            </li>

                        </ul>
                    </li>
                    <li><a style="font-size: .7rem"><i class="fa fa-building-o"></i> Penataan Aset<span
                                class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="/adminIrbanwil/formKIB">Kartu Inventaris Barang</a></li>
                            <li><a href="/adminIrbanwil/formKIR">Daftar Inventaris Ruangan</a></li>
                            <li><a href="/adminIrbanwil/formHolder">Holder</a></li>
                            <li><a href="/adminIrbanwil/formInventaris">Buku Inventaris Aset</a></li>
                            <li><a href="/adminIrbanwil/penilaianPenataanAset">Penilaian Indikator</a></li>
                        </ul>
                    </li>
                </ul>
            </li>




        </ul>
    </div>

</div>
<!-- /sidebar menu -->