<style>
    #rujukan {
        height: 85vh;
        overflow: scroll;
    }
</style>
<div class="row ">
    <div class="col-md-6 mt-2">
        <table class="table table-striped table-bordered">
            <thead class="bg-info">
                <tr>
                    <th style="vertical-align: middle" width="5%">No</th>
                    <th style="vertical-align: middle" width="70%">Nama Data</th>
                    <th class="text-center" width="25%">file_data </th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Laporan Penyelenggaraan Pemerintahan Desa (LPPD) Tahun {{ $tahun-1 }}
                    </td>
                    <td class="text-center">
                        @if($dalap['lppd'])
                        <a href="{{ asset('storage/'.$dalap['lppd']->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>2</td>
                    <td>Laporan Keterangan Penyelenggaraan Pemerintahan Desa (LKPD) Tahun {{ $tahun-1 }}</td>
                    <td class="text-center">
                        @if($dalap["lkpd"])
                        <a href="{{ asset('storage/'.$dalap['lkpd']->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>3</td>
                    <td>Peraturan Desa tentang Laporan Pertanggungjawaban APB Desa Tahun {{ $tahun-1 }}</td>
                    <td class="text-center">
                        @if($dalap["perdes_pj"])
                        <a href="{{ asset('storage/'.$dalap['perdes_pj']->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>4</td>
                    <td>Laporan Realisasi APB Desa TA {{ $tahun }} Semester 1</td>
                    <td class="text-center">
                        @if($dalap["lra_1"])
                        <a href="{{ asset('storage/'.$dalap['lra_1']->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>

                </tr>
                <tr>
                    <td>5</td>
                    <td>Laporan Realisasi APB Desa TA {{ $tahun }} Akhir Tahun</td>
                    <td class="text-center">
                        @if($dalap["lra_2"])
                        <a href="{{ asset('storage/'.$dalap['lra_2']->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>

            </tbody>
        </table>

    </div>
    <div class="col-md-6 mt-2" id="rujukan">
        <table class="table table-striped table-bordered">
            <thead class="bg-info">
                <tr>
                    <th>Rujukan Regulasi</th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        1. Permendagri Nomor 20 Tahun 2018 tentang Pengelolaan Keuangan Desa
                    </td>
                </tr>
                <tr>
                    <td>
                        &emsp; a. Laporan Realisasi APB Desa Semester 1
                        <br><br>
                        <img src="{{ asset('storage/regulasi/lra_semester1.JPG') }}" width="80%" class="ml-4">
                        <br><br>
                        &emsp; b. Peraturan Desa tentang Laporan Pertanggungjawaban APB Desa
                        <br><br>
                        <img src="{{ asset('storage/regulasi/pertanggungjawaban.JPG') }}" width="80%" class="ml-4">
                    </td>
                </tr>
                <tr>
                    <td>
                        2. Permendagri Nomor 46 Tahun 2016 tentang Laporan Kepala Desa
                    </td>
                </tr>
                <tr>
                    <td>
                        <img src="{{ asset('storage/regulasi/ruling_laporankades.JPG') }}" width="80%" class="ml-4">
                        <br><br>

                        a. Laporan Penyelenggaraan Pemerintahan Desa (LPPD)
                        <br><br>
                        <img src="{{ asset('storage/regulasi/lppd_1.JPG') }}" width="80%" class="ml-4">
                        <br>
                        <img src="{{ asset('storage/regulasi/lppd_2.JPG') }}" width="80%" class="ml-4">
                        <br><br>
                        b. Laporan Keterangan Penyelenggaraan Pemerintahan Desa (LKPD)
                        <br><br>
                        <img src="{{ asset('storage/regulasi/lkpd.JPG') }}" width="80%" class="ml-4">
                    </td>

                </tr>
            </tbody>

        </table>

    </div>
</div>