<div class="row ">
    <div class="col-md-8 mt-2">
        <p class="alert bg-warning text-dark" style="font-size: 1rem">Penilaian Indikator : Penataan Belanja
        </p>
        <form action="/adminIrbanwil/nilaiAkunbelanjaUpdate" method="post">
            @csrf
            <input type="hidden" name="asal_id" value="{{ $asal_id }}">
            <input type="hidden" name="tahun" value="{{ $tahun }}">
            <input type="hidden" name="aspek_id" value=2>
            <input type="hidden" name="indikator_id" value=8>

            <style>
                .smoke {
                    background-color: darkgray;
                }
            </style>
            <table class="table table-bordered">
                <thead>
                    <tr class="bg-info">
                        <th width="5%" style="vertical-align: middle">No</th>
                        <th width="40%" style="vertical-align: middle">Sub Indikator</th>
                        <th width="10%" class="text-center" style="vertical-align: middle">Bobot <br>(%)</th>
                        <th width="10%" class="text-center" style="vertical-align: middle">Keterisian<br>Data (%)</th>
                        <th width="10%" class="text-center" style="vertical-align: middle">Rata-rata <br> Nilai Dokumen
                        </th>
                        <th width="15%" class="text-center" style="vertical-align: middle">Nilai</th>
                        <th width="10%" class="text-center" style="vertical-align: middle">Skor</th>

                    </tr>
                </thead>
                <tbody>
                    <tr class="{{ $spp_null > 0 || $spp_ulang > 0 ? 'text-danger' : '' }}">
                        <td>1</td>
                        <td>Kelengkapan SPP Kegiatan</td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">30</td>
                        <td class="text-center" style="vertical-align: middle">{{ $datnilSPP->persen_data ?? 0
                            }}
                        </td>
                        <td class="text-center smoke" style="vertical-align: middle">{{ round($rata_spp,2) }}
                        </td>
                        <td class="text-center" style="vertical-align: middle">
                            <input type="hidden" name="spp_null" value="{{ $spp_null }}">
                            <input type="hidden" name="spp_ulang" value="{{ $spp_ulang }}">
                            <input type="hidden" name="sub_indikator_keuangan_id[]" value=3>
                            <input type="number" class="form-control text-center" style="font-size: .85rem"
                                name="nilai[]" value="{{ $datnilSPP->nilai_sementara  }}" required>
                        </td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">{{ $datnilSPP->skor }}</td>
                    </tr>
                    <tr class="{{ $bkp_null > 0 || $bkp_ulang > 0 ? 'text-danger' : '' }}">
                        <td>2</td>
                        <td>Kelengkapan TBPU dan Bukti Belanja</td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">30</td>
                        <td class="text-center" style="vertical-align: middle">{{ $datnilBKP->persen_data ?? 0
                            }}
                        </td>
                        <td class="text-center smoke" style="vertical-align: middle">{{ round($rata_bkp,2) }}
                        </td>
                        <td class="text-center" style="vertical-align: middle">
                            <input type="hidden" name="bkp_null" value="{{ $bkp_null }}">
                            <input type="hidden" name="bkp_ulang" value="{{ $bkp_ulang }}">
                            <input type="hidden" name="sub_indikator_keuangan_id[]" value=4>
                            <input type="number" class="form-control text-center" name="nilai[]"
                                style="font-size: .85rem" value="{{ round($datnilBKP->nilai_sementara)  }}" required>
                        </td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">{{ $datnilBKP->skor }}</td>
                    </tr>
                    <tr class="{{ $datnilBank && $datnilBank->perbaikan ? 'text-danger' : '' }}">
                        <td>3</td>
                        <td>Pembukuan</td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">10</td>
                        <td class="text-center" style="vertical-align: middle">{{ round($datnilBank->persen_data) ?? 0
                            }}
                        </td>
                        <td class="text-center smoke" style="vertical-align: middle">-
                        </td>
                        <td class="text-center" style="vertical-align: middle">
                            <input type="hidden" name="sub_indikator_keuangan_id[]" value=5>
                            <input type="number" class="form-control text-center" name="nilai[]"
                                style="font-size: .85rem" value="{{ $datnilBank->nilai_sementara  }}" required>
                        </td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">{{ $datnilBank->skor }}</td>
                    </tr>
                    <tr class="{{ $uji_null || $data_upet==0 ? 'text-danger' : '' }} ">
                        <td>4</td>
                        <td>Validasi / Uji Petik Bukti Belanja</td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">30</td>
                        <td class="text-center" style="vertical-align: middle">{{ $data_upet }}
                        </td>
                        <td class="text-center smoke" style="vertical-align: middle">-
                        </td>
                        <td class="text-center" style="vertical-align: middle">
                            <input type="hidden" name="data_upet" value="{{ $data_upet }}">
                            <input type="hidden" name="uji_null" value="{{ $uji_null }}">
                            <input type="hidden" name="sub_indikator_keuangan_id[]" value=6>
                            <input type="number" class="form-control text-center" name="nilai[]"
                                value="{{ $nilai_upet ?? 0 }}" style="font-size: .85rem" readonly required>
                        </td>
                        <td class="text-center bg-secondary" style="vertical-align: middle">{{ $datnilUji->skor ?? 0 }}
                        </td>
                    </tr>

                </tbody>

                <tr>
                    <td colspan="7" class="text-muted">
                        <p><i>Petunjuk Penilaian : <br>
                                <span class="mr-1">1.</span> <span>Untuk sub indikator spp dan tbpu,
                                    keterisian data merupakan
                                    persentase realisasi spp/tbpu terhadap jumlah anggaran kegiatan</span><br>
                                <span class="mr-1">2.</span>Perhitungan nilai sub indikator spp/tbpu dapat merujuk dari
                                (keterisian data x rata-rata nilai per dokumen), dan dengan pertimbangan <br>
                                &emsp;nilai akhir = 100 jika rata-rata nilai dokumen = 100 dan
                                keterisian data diatas 95% <br>
                                3. Nilai sub indikator hasil uji petik otomatis terisi jika penilaian uji petik telah
                                dilakukan
                            </i></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="7" class="bg-info">
                        <div class="form-group">
                            <label for="kesimpulan">Catatan / Kesimpulan</label>
                            <input type="hidden" name="catatan_sementara" id="kesimpulan" autofocus>
                            <trix-editor input="kesimpulan" class="bg-white">
                                {!! $catatan->catatan_sementara !!}
                            </trix-editor>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="7" class="bg-info">
                        <div class="form-group">
                            <label for="saran">Saran / Rekomendasi</label>
                            <input type="hidden" name="rekom_sementara" id="saran">
                            <trix-editor input="saran" class="bg-white">{!! $catatan->rekom_sementara ?? '' !!}
                            </trix-editor>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="7" class="text-right">
                        <button type="submit" class="btn btn-primary">Update Nilai</button>
                    </td>
                </tr>


            </table>
        </form>
    </div>
    <div class="col-md-3 mt-2">
        <p class="alert alert-info" style="font-size: 1rem">Capaian Indikator : </br>Penataan Belanja</p>
        <div class="card p-2">
            <label for="">Keterisian Data</label>
            <div class="progress progress_sm mb-1 ">
                <div class="progress-bar bg-green" role="progressbar"
                    data-transitiongoal="{{ $rekap->persen_data ?? 0 }}">
                </div>
            </div>
            <small style="font-size: .7rem">{{ round($rekap->persen_data) ?? 0 }}% Complete</small>
        </div>
        <div class="card p-2">
            <label for="">Nilai Indikator </label>
            <div class="progress progress_sm mb-1 ">
                <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="{{ $rekap->nilai ?? 0}}">
                </div>
            </div>
            <small style="font-size: .8rem">{{ round($rekap->nilai,2) }}</small>
        </div>
        <div class="card p-2 d-flex">
            <p class="mb-0">Bobot : {{ $rekap->bobot }}%</p>
            <p>Skor : {{ $rekap->skor }}</p>
        </div>

    </div>
</div>