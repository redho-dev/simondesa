<div class="row">
    <div class="col-md-8">
        <form action="/adminIrbanwil/tunggakanTambah" method="post" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="asal_id" value="{{ $asal_id }}">
            <input type="hidden" name="tahun" value="{{ $tahun }}">

            <table class="table table-bordered">
                <thead>
                    <tr class="bg-info">
                        <th>#</th>
                        <th width="25%" class="text-center">Tunggakan Pajak s.d Saat Ini <br> (Rp)</th>
                        <th width="35%" class="text-center">Sumber Data</th>
                        <th width="35%" class="text-center">Upload Bukti Data</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td><input type="text" name="tunggakan" class="form-control angka text-center"
                                style="font-size: .8rem" required>
                        </td>
                        <td><input type="text" name="sumber_data" class="form-control" style="font-size: .8rem"
                                required></td>
                        <td>
                            <input type="file" name="bukti_data" class="form-control" style="font-size: .8rem" required>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4" class="text-center">
                            <button class="btn btn-sm btn-primary">Kirim</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>
    </div>
</div>