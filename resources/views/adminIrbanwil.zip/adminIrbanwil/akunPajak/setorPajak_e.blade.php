<div class="row">
    <div class="col-md-12">
        <p class="text-primary mt-4">A. Data Pajak TA {{ $tahun }} yg Terinput di SIMONDES</p>
        <table class="table table-bordered">
            <thead class="bg-success">
                <tr>
                    <th class="text-center" style="vertical-align: middle">Jumlah Anggaran <br>Belanja</th>
                    <th class="text-center" style="vertical-align: middle">Jumlah TBPU </th>
                    <th class="text-center" style="vertical-align: middle">Jumlah Potongan PPn</th>
                    <th class="text-center" style="vertical-align: middle">Jumlah Potongan PPh</th>
                    <th class="text-center" style="vertical-align: middle">Total Potongan Pajak</th>
                    <th class="text-center" style="vertical-align: middle">PPn disetor</th>
                    <th class="text-center" style="vertical-align: middle">PPh disetor</th>
                    <th class="text-center" style="vertical-align: middle">Total Pajak disetor</th>
                    <th class="text-center" style="vertical-align: middle">Pajak Blm disetor</th>
                    <th class="text-center" style="vertical-align: middle">Progress Pajak</th>
                </tr>
                <tr>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(Rp)</th>
                    <th class="text-center">(%)</th>

                </tr>

            </thead>
            <tbody>
                <tr>
                    <td class="text-center angka">{{ $totalBelanja }}</td>
                    <td class="text-center angka">{{ $jumlahbkp }}</td>
                    <td class="text-center angka">{{ $ppn }}</td>
                    <td class="text-center angka">{{ $pph }}</td>
                    <td class="text-center angka">{{ $totalPajak }}</td>
                    <td class="text-center angka">{{ $setorppn }}</td>
                    <td class="text-center angka">{{ $setorpph }}</td>
                    <td class="text-center angka">{{ $setorPajak }}</td>
                    <td class="text-center angka">{{ $blmSetor }}</td>
                    <td class="text-center">{{ $progress }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="row">
    <div class="col-md-7">
        <p class="text-primary">B. Hasil Rekon Pajak dari Kantor Pajak Pratama Kotabumi</p>
        <form action="/adminIrbanwil/pajakTerbayarUpdate" method="post">
            @csrf
            <input type="hidden" name="asal_id" value="{{ $asal_id }}">
            <input type="hidden" name="tahun" value="{{ $tahun }}">

            <table class="table table-bordered">
                <thead class="bg-info">
                    <tr>
                        <th class="text-center" style="vertical-align: middle">Koreksi Jumlah <br>Potongan Pajak TA {{
                            $tahun }} <br> (Rp)</th>
                        <th class="text-center" style="vertical-align: middle">Koreksi Jumlah Pajak <br>Terbayar TA {{
                            $tahun
                            }} <br>(Rp)</th>
                        <th class="text-center" style="vertical-align: middle">Sisa Pajak <br> Terhutang TA {{ $tahun }}
                            <br> (Rp)
                        </th>
                        <th class="text-center" style="vertical-align: middle">Prosentase <br>Pemenuhan Pajak <br> (%)
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <input type="text" name="potongan_pajak" class="form-control angka  text-center"
                                value="{{ $setor[0]->potongan_pajak }}" required>
                        </td>
                        <td>
                            <input type="text" name="pajak_terbayar" class="form-control angka text-center"
                                value="{{ $setor[0]->pajak_terbayar }}" required>
                        </td>
                        <td>
                            <input type="text" class="form-control angka text-center"
                                value="{{ $setor[0]->hutang_pajak }}" readonly>
                        </td>
                        <td>
                            <input type="text" class="form-control text-center" value="{{ $setor[0]->prosentase }}"
                                readonly>
                        </td>
                    </tr>
                    <tr class="text-center">
                        <td colspan="4"><button class="btn btn-primary">UPDATE</button></td>
                    </tr>
                </tbody>
            </table>
        </form>
    </div>
</div>