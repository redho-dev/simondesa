<div class="row ">
    <div class="col-md-9 mt-2">
        <table class="table table-striped table-bordered">
            <thead class="bg-info">
                <tr>
                    <th style="vertical-align: middle" width="5%">No</th>
                    <th style="vertical-align: middle" width="40%">Nama Data</th>
                    <th class="text-center" width="25%">file_data <br> <small>(klik untuk lihat)</small></th>
                    <th width="30%">Keterangan</th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Perdes dan Dokumen RPJMDes</td>
                    <td class="text-center">
                        @if($dokrpjmd->file_data)
                        <a href="{{ asset('storage/'.$dokrpjmd->file_data) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>
                        @if($norpjmd->uraian)
                        <p>Perdes Nomor : {{ $norpjmd->uraian }}</p>
                        @endif
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>SK Tim Penyusunan RKP Desa Tahun {{ $tahun }}</td>
                    <td class="text-center">
                        @if($sktim && $sktim->isidata)
                        <a href="{{ asset('storage/'.$sktim->isidata) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>BAC Musyawarah Dusun</td>
                    <td class="text-center">
                        @if($musdus && $musdus->isidata)
                        <a href="{{ asset('storage/'.$musdus->isidata) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>BAC Musrenbangdes</td>
                    <td class="text-center">
                        @if($musren && $musren->isidata)
                        <a href="{{ asset('storage/'.$musren->isidata) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td class="text-center">
                        @if($fotomusren && $fotomusren->isidata)
                        <a href="{{ asset('storage/'.$fotomusren->isidata) }}" target="_blank">
                            <img src="{{ asset('storage/'.$fotomusren->isidata) }}" width="50px">
                        </a>
                        @endif
                    </td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Perdes dan Dokumen RKP Desa Tahun {{ $tahun }}</td>
                    <td class="text-center">
                        @if($dokrkpd && $dokrkpd->isidata)
                        <a href="{{ asset('storage/'.$dokrkpd->isidata) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Ketepatan Waktu Penetapan Perdes RKP Desa Tahun {{ $tahun }}</td>
                    <td class="text-center">
                        @if($tglrkpd && $tglrkpd->isidata)
                        <p>{{ $tglrkpd->isidata }}</p>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>
                        Perdes RKP Desa Tahun {{ $tahun }} ditetapkan paling lambat akhir bulan september tahun {{
                        $tahun-1 }}
                    </td>
                </tr>

                <tr>
                    <td>7</td>
                    <td>Dokumen RAPBDes Tahun {{ $tahun }}</td>
                    <td class="text-center">
                        @if($dok_rapbdes)
                        <a href="{{ asset('storage/'.$dok_rapbdes) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>

                    </td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>BAC Pembahasan RAPBDes dengan BPD</td>
                    <td class="text-center">
                        @if($bac)
                        <a href="{{ asset('storage/'.$bac) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>

                        @if($foto_musdes)
                        <p>foto musdes pembahasan RAPBDes</p>
                        <a href="{{ asset('storage/'.$foto_musdes) }}" target="_blank">
                            <img src="{{ asset('storage/'.$foto_musdes) }}" width="100px">
                        </a>
                        @endif

                    </td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Keputusan BPD tentang Persetujuan RAPBDes menjadi APBDes TA {{ $tahun }}</td>
                    <td class="text-center">
                        @if($keputusan_bpd)
                        <a href="{{ asset('storage/'.$keputusan_bpd) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>

                    </td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Hasil Evaluasi Camat atas Raperdes APBDes TA {{ $tahun }}</td>
                    <td class="text-center">
                        @if($evaluasi)
                        <a href="{{ asset('storage/'.$evaluasi) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>

                    </td>
                </tr>

                <tr>
                    <td>11</td>
                    <td>Perdes dan Lampiran/Dokumen APBDes TA {{ $tahun }}</td>
                    <td class="text-center">
                        @if($apbdes_murni)
                        <a href="{{ asset('storage/'.$apbdes_murni) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>
                        Perdes Nomor {{ $nomor_murni ?? '' }}
                    </td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>Analisa, Gambar dan RAB Pembangunan Fisik (APBDes Murni TA {{ $tahun }})</td>
                    <td class="text-center">
                        @if($desain_murni)
                        <a href="{{ asset('storage/'.$desain_murni) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>
                    </td>
                </tr>
                <tr>
                    <td>13</td>
                    <td>Ketepatan Waktu Penetapan Perdes APBDes TA {{ $tahun }}</td>
                    <td class="text-center">
                        @if($tgl_murni)
                        <p>{{ $tgl_murni }}</p>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>
                        Perdes APBDes TA {{ $tahun }} ditetapkan paling lambat 31 Desember Tahun {{ $tahun-1 }}
                    </td>
                </tr>
                <tr>
                    <td>14</td>
                    <td>Perkades dan Lampiran/Dokumen Penjabaran (APBDes Murni TA {{ $tahun }})</td>
                    <td class="text-center">
                        @if($penjabaran_murni)
                        <a href="{{ asset('storage/'.$penjabaran_murni) }}" target="_blank">
                            <img src="/img/logo-pdf.jpg" width="50px">
                        </a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif
                    </td>
                    <td>
                    </td>
                </tr>
            </tbody>

        </table>

    </div>
</div>