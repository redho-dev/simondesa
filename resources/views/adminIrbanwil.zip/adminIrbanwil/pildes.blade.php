@foreach($desa as $d)
<option value="{{ $d->asal }}">{{ $d->asal}}</option>
@endforeach