<div class="row ">
    <div class="col-md-7 mt-2">
        <table class="table table-striped table-bordered">
            <thead class="bg-info">
                <tr>
                    <th style="vertical-align: middle" width="5%">No</th>
                    <th style="vertical-align: middle" width="70%">Nama Data</th>
                    <th class="text-center" width="25%">file_data <br> <small>(klik untuk lihat)</small></th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Buku Surat Masuk/Keluar</td>
                    <td class="text-center">
                        @if($data[0]->file_data)
                        <a href="{{ asset('storage/'.$data[0]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>2</td>
                    <td>Rekap Bulanan Daftar Hadir Perangkat Semester 1</td>
                    <td class="text-center">
                        @if($data[1]->file_data)
                        <a href="{{ asset('storage/'.$data[1]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>3</td>
                    <td>Rekap Bulanan Daftar Hadir Perangkat Semester 2</td>
                    <td class="text-center">
                        @if($data[2]->file_data)
                        <a href="{{ asset('storage/'.$data[2]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>4</td>
                    <td>Buku Register Perdes/Perkades/SK</td>
                    <td class="text-center">
                        @if($data[3]->file_data)
                        <a href="{{ asset('storage/'.$data[3]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>5</td>
                    <td>Buku Rekap Kependudukan</td>
                    <td class="text-center">
                        @if($data[4]->file_data)
                        <a href="{{ asset('storage/'.$data[4]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>

            </tbody>
        </table>

    </div>
</div>