<div class="row ">
    <div class="col-md-7 mt-2">
        <table class="table table-striped table-bordered">
            <thead class="bg-info">
                <tr>
                    <th style="vertical-align: middle" width="5%">No</th>
                    <th style="vertical-align: middle" width="70%">Nama Data</th>
                    <th class="text-center" width="25%">file_data <br> <small>(klik untuk lihat)</small></th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Peraturan Desa Tentang Struktur Organisasi dan Tatakerja (SOTK) Pemerintah Desa</td>
                    <td class="text-center">
                        @if($data[0]->file_data)
                        <a href="{{ asset('storage/'.$data[0]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>2</td>
                    <td>SK Lembaga Pemberdayaan Masyarakat (LPM)</td>
                    <td class="text-center">
                        @if($data[1]->file_data)
                        <a href="{{ asset('storage/'.$data[1]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>3</td>
                    <td>SK Karang Taruna</td>
                    <td class="text-center">
                        @if($data[2]->file_data)
                        <a href="{{ asset('storage/'.$data[2]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>4</td>
                    <td>SK Perlindungan Masyarakat (Linmas)</td>
                    <td class="text-center">
                        @if($data[3]->file_data)
                        <a href="{{ asset('storage/'.$data[3]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>5</td>
                    <td>SK Kepengurusan PKK</td>
                    <td class="text-center">
                        @if($data[4]->file_data)
                        <a href="{{ asset('storage/'.$data[4]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>6</td>
                    <td>Foto Kantor Desa</td>
                    <td class="text-center">
                        @if($data[5]->file_data)
                        <a href="{{ asset('storage/'.$data[5]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[5]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>7</td>
                    <td>Papan Struktur Pemerintah Desa</td>
                    <td class="text-center">
                        @if($data[6]->file_data)
                        <a href="{{ asset('storage/'.$data[6]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[6]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
                <tr>
                    <td>8</td>
                    <td>Foto Kantor/Sekretariat BPD</td>
                    <td class="text-center">
                        @if($data[7]->file_data)
                        <a href="{{ asset('storage/'.$data[7]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[7]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>

                </tr>
            </tbody>
        </table>

    </div>
</div>