<div class="row ">
    <div class="col-md-7 mt-2">
        <table class="table table-striped table-bordered">
            <thead class="bg-info">
                <tr>
                    <th style="vertical-align: middle" width="5%">No</th>
                    <th style="vertical-align: middle" width="25%">Nama Data</th>
                    <th class="text-center" width="20%">file_data <br> <small>(klik untuk lihat)</small></th>
                    <th class="text-center" style="vertical-align: middle" width="50%">Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Dokumen Dasar Hukum Pembentukan Desa</td>
                    <td class="text-center">
                        @if($data[0]->file_data)
                        <a href="{{ asset('storage/'.$data[0]->file_data) }}" target="_blank"><img
                                src="{{ asset('/img/logo-pdf.jpg') }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>
                    <td>{{ $dawil[0]->isidata }}</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Pilar Batas Utara Desa</td>
                    <td class="text-center">
                        @if($data[1]->file_data)
                        <a href="{{ asset('storage/'.$data[1]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[1]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>
                    <td>{{ $dawil[1]->isidata }}</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Pilar Batas Selatan Desa</td>
                    <td class="text-center">
                        @if($data[2]->file_data)
                        <a href="{{ asset('storage/'.$data[2]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[2]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>
                    <td>{{ $dawil[2]->isidata }}</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Pilar Batas Barat Desa</td>
                    <td class="text-center">
                        @if($data[3]->file_data)
                        <a href="{{ asset('storage/'.$data[3]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[3]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>
                    <td>{{ $dawil[3]->isidata }}</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Pilar Batas Timur Desa</td>
                    <td class="text-center">
                        @if($data[4]->file_data)
                        <a href="{{ asset('storage/'.$data[4]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[4]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>
                    <td>{{ $dawil[4]->isidata }}</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Peta Batas Desa</td>
                    <td class="text-center">
                        @if($data[5]->file_data)
                        <a href="{{ asset('storage/'.$data[5]->file_data) }}" target="_blank"><img
                                src="{{ asset('storage/'.$data[5]->file_data) }}" alt="" width="50px"></a>
                        @else
                        <p class="text-danger">data kosong</p>
                        @endif

                    </td>
                    <td>{{ $dawil[5]->isidata }}</td>
                </tr>
            </tbody>
        </table>

    </div>
    <div class="col-md-5 mt-2" style="heigth : 100%; overflow: hidden">
        <p class="alert bg-success text-dark" style="font-size: 1rem">Langkah Pengujian</p>
        <div class="card pl-3" style="height: 100vh; overflow: scroll">
            <p>Regulasi Terkait : <br>
                1. <a href="{{ asset('storage/regulasi/Permendagri-Nomor-45-Tahun-2016-batas_desa.pdf') }}"
                    target="_blank" class="text-primary">Permendagri Nomor 45
                    Tahun 2016 tentang Pedoman Penetapan dan Penegasan Batas Desa</a>
                <br>
                2. <a href="{{ asset('storage/regulasi/perka_BIG_3_2016.pdf') }}" target="_blank"
                    class="text-primary">Perka
                    BIG Nomor 3 tahun 2016 tentang Spesifikasi Teknis Penyajian Peta Desa</a> <br>
                3. <a href="{{ asset('storage/regulasi/Peraturan BIG Nomor 15 Tahun 2019.pdf') }}" target="_blank"
                    style="font-size: .7rem" class="text-primary">Peraturan BIG Nomor 15 tahun 2019 tentang Metode
                    Kartometrik pada
                    Penetapan dan Penegasan
                    Batas Desa/Kelurahan</a>
            </p>
            <p class="mb-0">Langkah Pengujian : </p>
            <p class="mt-0 mb-0"> 1. Dokumen Dasar Hukum Pembentukan Desa</p>
            <p class="ml-3 mb-0" ">Cek Apakah benar dokumen yang diupload merupakan produk hukum
                yang menjadi dasar atau
                asal
                susul pembentukan desa, lakukan konfirmasi ke Dinas PMD, Bagian Tapem serta Kecamatan </p>
            <p class=" mt-0 mb-0"> 2. Pilar Batas Desa</p>
            <p class="ml-4 mb-0">a. Pilar Batas antar desa antar kecamatan</p>
            <p class="ml-4 mb-0 ">&emsp; - dapat menggunakan pilar batas antar kecamatan dengan standarisasi seuai <br>
                &emsp; &emsp;permendagri tentang penegasan batas daerah</p>
            <p class="ml-4 mb-0">b. Pilar Batas antar desa dalam satu kecamatan</p>
            <p class="ml-4 mb-0">&emsp;standirasi pilar sbb : </p>
            <img src="{{ asset('storage/referensi/standar-patok-desa.JPG') }}" alt="">
            <p class="ml-4 mb-2">&emsp;contoh pilar sbb : </p>
            <div class="row">
                <div class="col-6 text-center">
                    <img src="{{ asset('storage/referensi/patok1.JPG') }}" width="100%" height="250px">
                </div>
                <div class="col-6">
                    <img src="{{ asset('storage/referensi/patok2.png') }}" width="100%" height="250px">
                </div>
            </div>
            <p class="mt-4">3. Peta Batas Desa</p>
            <p>Peta Batas Desa adalah Peta hasil proses penegasan batas desa.
                peta ini menggunakan ketentuan dan spesifikasi peta kerja,
                ditambahi informasi daftar titik kartometrik dan informasi pilar
                batas yang sudah terpasang di lapangan</p>
            <p>peta batas desa dapat disajikan dalam bentuk peta administrasi wilayah desa atau peta tematik lainnya,
                dengan standarisasi sebagaimana diatur dalam Perka BIG Nomor 3 Tahun 2016 dan Perka BIG Nomor 15 Tahun
                2019, dimana ketentuan utamnya yaitu :</p>
            a. Penyajian peta dalam garis koordinat </br>
            b. Menampilkan Nama Desa, Kecamatan dan Kabupaten </br>
            d. Menampilkan garis batas, arah dan legenda (jalan, infrastruktur umum, sawah, dll) </br>
            e. Skala Peta ( 1 : 2.500 s.d 1 : 10.000 ) </br>
            <p class="mt-2"> Contoh Peta Desa : </p>
            <a href="{{ asset('/referensi/peta1.jpg') }}" target="_blank"><img src="{{ asset('/referensi/peta1.jpg') }}"
                    width="80%"></a><br>
            <a href="{{ asset('/referensi/petadesa.jpg') }}" target="_blank"><img
                    src="{{ asset('/referensi/petadesa.jpg') }}" width="80%"></a>

        </div>
    </div>
</div>