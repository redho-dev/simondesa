<p class="alert alert-info" style="font-size: 1rem">Silahkan Cek dan Nilai Realisasi Belanja Modal Yang Berupa Aset
    Barang
    Berdasarkan APB Desa TA {{ $tahun }}
</p>
<div class="row">
    <div class="col-md-9">


        <p class="mb-0 pb-0 text-primary">Catatan :</p>
        <p class="mb-0 pb-0 text-primary">1. Contoh Belanja Modal Aset Barang : Komputer, Laptop, Printer, Mebeleur,
            Kendaraan,
            Peralatan
            Elektronik, Teralis,
            Dan sebagainya</p>
        <p class="mb-0 pb-0 text-primary">2. Dalam Hal ini Belanja Modal Upah dan Belanja Modal Material Pembanguan
            Tidak
            Termasuk Sebagai
            Belanja Modal Aset
            Barang</p>
        <p class="mb-0 pb-0 text-primary">3. Seluruh Belanja Modal Aset Barang dalam APB Desa TA {{ $tahun }} Wajib di
            Input
            dalam SIMONDES</p>
        <p class="mb-0 pb-0 text-primary">4. Input Belanja Modal Aset Barang dilakukan per Unit atau per Satuan Barang
            dan
            Secara Otomatis Ditambahkan dalam Buku Inventaris Aset Desa</p>
        <p class="mb-0 pb-0 text-danger">5. Belanja Modal Aset Barang Yang Tidak di Input Dalam SIMONDES akan menjadi
            Temuan
            Inspektorat (Pengembalian ke Kas Desa)</p>
    </div>
    <div class="col-md-3 text-center">
        <p>Cek Dokumen APBDes TA {{ $tahun }}</p>
        <a href="{{ asset('storage/'.$apbdes) }}" target="_blank"><img src="/img/logo-pdf.jpg" width="60px"></a>
        <p class="mt-0 pt-0 text-center">{{ $status }}</p>
    </div>
</div>

<hr>

<?php $i=1; ?>
@foreach($barangs as $br)
<div class="row">
    <div class="col-md-12">

        <table class="table table-bordered" id="tabel_{{ $i }}">
            <thead class="bg-secondary">
                <th>No</th>
                <th>Nama Barang</th>
                <th class="text-center">Merk/Type</th>
                <th class="text-center">Harga (Rp)</th>
                <th class="text-center">Foto Barang</th>
                <th class="text-center">Bukti Belanja</th>
                <th class="text-center">Nilai</th>
            </thead>
            <tbody>

                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $br->nama_barang }}</td>
                    <td class="text-center">{{ $br->merk_type }}</td>
                    <td class="text-center"><span class="angka">{{ $br->harga }}</span></td>
                    <td class="text-center">
                        <a href="{{ asset('storage/'.$br->foto_barang) }}" target="_blank"><img
                                src="{{ asset('storage/'.$br->foto_barang) }}" width="150px"></a>
                    </td>
                    <td class="text-center">
                        <a href="{{ asset('storage/'.$br->bukti_belanja) }}" target="_blank"><img
                                src="/img/logo-pdf.jpg" width="75px"></a>
                    </td>
                    <td class="text-center">
                        @if($br->nilai_sementara)
                        <p class="bg-dark p-2 text-white" style="font-size: 1.2rem">{{ $br->nilai_sementara }}</p>
                        @else
                        <p class="bg-dark p-2 text-white">Belum dinilai</p>
                        @endif
                    </td>
                </tr>
                <tr>
                    <td colspan="7" class="text-center pl-4">

                        @if($br->tgl_cek_fisik)
                        <button id="{{ $i }}" class="btn btn-sm btn-success tamNil">Update Nilai & Catatan
                            &ensp;<span class="fa fa-angle-double-down"></span></button>
                        @else
                        <button id="{{ $i }}" class="btn btn-sm btn-primary tamNil">+ Nilai dan Catatan &ensp;<span
                                class="fa fa-angle-double-down"></span></button>
                        @endif

                    </td>

                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="row mt-0 aset_{{ $i }} hasil_cek" style="display: none;">
    <div class="col-md-12">

        <form action="/adminIrbanwil/nilaiPengAset" method="post" class="formaset">

            @csrf
            <input type="hidden" name="asal_id" value="{{ $asal_id }}">
            <input type="hidden" name="tahun" value="{{ $tahun }}">
            <input type="hidden" name="id" value="{{ $br->id }}">
            <input type="hidden" name="tabel" value="tabel_{{ $i }}">

            <table class="table table-bordered">
                <tr style="background-color: antiquewhite">
                    <td colspan="8">
                        <div class="form-row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="status">Tgl Cek Fisik</label>

                                    @if($br && $br->tgl_cek_fisik)
                                    <input type="date" name="tgl_cek_fisik" class="form-control"
                                        style="font-size: .8rem" value="{{ $br->tgl_cek_fisik }}" required>
                                    @else
                                    <input type="date" name="tgl_cek_fisik" class="form-control"
                                        style="font-size: .8rem" required>
                                    @endif



                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="status">Kategori Temuan</label>
                                    <select class="form-control" name="status_temuan" style="font-size: .8rem" required>

                                        @if($br && $br->status_temuan)
                                        <option value="">-- pilih --</option>
                                        <option value=1 {{ $br->status_temuan == 1 ? 'selected' : ''
                                            }}>Indikasi_Fiktif</option>
                                        <option value=2 {{ $br->status_temuan == 2 ? 'selected' : ''
                                            }}>Indikasi Mark Up</option>
                                        <option value=3 {{ $br->status_temuan == 3 ? 'selected' : ''
                                            }}>Barang Tidak Sesuai Spek</option>
                                        <option value=4 {{ $br->status_temuan == 4 ? 'selected' : ''
                                            }}>Kekurangan Administratif</option>
                                        <option value=5 {{ $br->status_temuan == 5 ? 'selected' : ''
                                            }}>Lainnya</option>
                                        <option value=6 {{ $br->status_temuan == 6 ? 'selected' : ''
                                            }}>Nihil</option>
                                        @else
                                        <option value="">-- pilih --</option>
                                        <option value=1>Indikasi_Fiktif</option>
                                        <option value=2>Indikasi Mark Up</option>
                                        <option value=3>Barang Tidak Sesuai Spek</option>
                                        <option value=4>Kekurangan Administratif</option>
                                        <option value=5>Lainnya</option>
                                        <option value=6>Nihil</option>
                                        @endif
                                    </select>
                                </div>
                            </div>

                            <div class="col">
                                <div class="form-group">
                                    <label for="status">Estimasi Kerugian (Rp)</label>

                                    @if($br && $br->estimasi_kerugian)
                                    <input type="text" name="estimasi_kerugian" class="form-control angka"
                                        style="font-size: .8rem" value="{{ $br->estimasi_kerugian }}">
                                    @else
                                    <input type="text" name="estimasi_kerugian" class="form-control angka"
                                        style="font-size: .8rem">
                                    @endif
                                </div>
                            </div>

                            <div class="col">
                                <div class="form-group">
                                    <label for="status">Nilai (0 - 100)</label>

                                    @if($br && $br->nilai_sementara)
                                    <input type="number" name="nilai_sementara" idkeg="{{ $br->id }}"
                                        class="form-control nilaiKeg" style="font-size: .8rem" required
                                        value="{{ $br->nilai_sementara }}">
                                    @else
                                    <input type="number" name="nilai_sementara" idkeg="{{ $br->id }}"
                                        class="form-control nilaiKeg" style="font-size: .8rem" required>
                                    @endif
                                </div>
                            </div>
                        </div>

                    </td>
                </tr>

                <tr>
                    <td colspan="4" class="bg-secondary">

                        @if($br->catatan_sementara)
                        <div class="form-group">
                            <label for="rekomendasi">Catatan / Temuan</label>
                            <input type="hidden" name="catatan_sementara" id="catatan_awal_{{ $br->id }}" autofocus>
                            <trix-editor input="catatan_awal_{{ $br->id }}" class="bg-light">
                                {!! $br->catatan_sementara ?? '' !!}
                            </trix-editor>
                        </div>
                        @else
                        <div class="form-group">
                            <label for="rekomendasi">Catatan / Temuan</label>
                            <input type="hidden" name="catatan_sementara" id="catatan_{{ $br->id }}" autofocus>
                            <trix-editor input="catatan_{{ $br->id }}" class="bg-light">
                            </trix-editor>
                        </div>
                        @endif
                    </td>
                    <td colspan="4" class="bg-secondary">

                        @if($br->rekomendasi_sementara)
                        <div class="form-group">
                            <label for="rekomendasi">Saran / Rekomendasi</label>
                            <input type="hidden" name="rekomendasi_sementara" id="rekomendasi_awal_{{ $br->id }}"
                                autofocus>
                            <trix-editor input="rekomendasi_awal_{{ $br->id }}" class="bg-light">
                                {!! $br->rekomendasi_sementara ?? '' !!}
                            </trix-editor>
                        </div>
                        @else
                        <div class="form-group">
                            <label for="rekomendasi">Saran / Rekomendasi</label>
                            <input type="hidden" name="rekomendasi_sementara" id="rekomendasi_{{ $br->id }}" autofocus>
                            <trix-editor input="rekomendasi_{{ $br->id }}" class="bg-light">
                            </trix-editor>
                        </div>
                        @endif
                    </td>

                </tr>
                <tr>
                    <td colspan="8" class="text-center">

                        @if($br && $br->tgl_cek_fisik)
                        <button type="submit" class="btn btn-success btn-sm">UPDATE &ensp;<span
                                class="fa fa-send"></span></button>
                        @else
                        <button type="submit" class="btn btn-primary btn-sm">KIRIM &ensp;<span
                                class="fa fa-send"></span></button>
                        @endif
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
<hr>
<br>
<?php $i++; ?>
@endforeach