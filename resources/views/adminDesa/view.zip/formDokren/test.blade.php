<div class="row">
    <div class="col-md-6">
        <div class="card">
            <h1>TESTERRR BERHASIL</h1>
        </div>
    </div>

</div>